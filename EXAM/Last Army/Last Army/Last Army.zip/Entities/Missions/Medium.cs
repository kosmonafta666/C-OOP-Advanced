﻿
public class Medium : Mission
{
    private const double EnduranceRequred = 50;

    public Medium(double scopeToComplete) 
        : base(EnduranceRequred, scopeToComplete)
    {
    }
}

