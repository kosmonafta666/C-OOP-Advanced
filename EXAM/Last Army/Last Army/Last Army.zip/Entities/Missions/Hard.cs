﻿
public class Hard : Mission
{
    private const double EnduranceRequred = 80;

    public Hard(double scopeToComplete) 
        : base(EnduranceRequred, scopeToComplete)
    {
    }
}

