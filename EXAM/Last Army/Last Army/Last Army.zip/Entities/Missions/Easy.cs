﻿
public class Easy : Mission
{
    private const double EnduranceRequred = 20;

    public Easy(double scopeToComplete) : 
        base(EnduranceRequred, scopeToComplete)
    {
    }
}

