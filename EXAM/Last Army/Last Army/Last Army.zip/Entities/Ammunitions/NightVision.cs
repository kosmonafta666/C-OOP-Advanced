﻿
public class NightVision : Ammunition
{
    private const double WeightFactor = 0.8;

    public NightVision(string name)
        : base (name, WeightFactor)
    {
    }
}
