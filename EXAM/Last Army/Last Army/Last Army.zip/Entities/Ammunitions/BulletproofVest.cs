﻿
public class BulletproofVest : Ammunition
{
    private const double WeightFactor = 3.4;

    public BulletproofVest(string name)
        : base(name, WeightFactor)
    {
    }
}
