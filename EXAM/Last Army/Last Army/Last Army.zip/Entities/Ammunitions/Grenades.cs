﻿
public class Grenades : Ammunition
{
    private const double WeightFactor = 1.0;

    public Grenades(string name) 
        : base (name, WeightFactor)
    {
    }
}
