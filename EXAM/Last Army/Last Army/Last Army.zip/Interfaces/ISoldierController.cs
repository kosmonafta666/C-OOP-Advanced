﻿
public interface ISoldierController
{

}

