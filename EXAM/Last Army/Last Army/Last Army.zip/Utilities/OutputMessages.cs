﻿
public static class OutputMessages
{
    public static string MissionSuccessful = "";

    public static string MissionOnHold = "";

    public static string MissionDeclined = "";

    public static string SoldierToString = "";

}

