﻿namespace Geneiric_Box
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class GeneiricBox
    {
        public static void Main(string[] args)
        {
            //read the number of elements;
            var numberOfElements = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfElements; i++)
            {

                //read the current string element;
                var currElement = int.Parse(Console.ReadLine());

                //create box elelment and print it;
                Box<int> box = new Box<int>(currElement);

                Console.WriteLine(box);
            }
            
        }
    }
}
