﻿namespace Geneiric_Box
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class GeneiricBox
    {
        public static void Main(string[] args)
        {
            //read the number of elements;
            var numberOfElements = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfElements; i++)
            {

                //read the current string element;
                var currElement = Console.ReadLine();

                //create box elelment and print it;
                Box<string> box = new Box<string>(currElement);

                Console.WriteLine(box);
            }
            

            
        }
    }
}
