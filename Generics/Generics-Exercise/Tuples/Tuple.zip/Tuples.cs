﻿namespace Tuples
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Tuples
    {
        public static void Main(string[] args)
        {
            //read the first input and print the tuple;
            var inputLine1 = Console.ReadLine()
                .Split(' ');

            var names = $"{inputLine1[0]} {inputLine1[1]}";

            Tuple<string, string> tp1 = new Tuple<string, string>(names, inputLine1[2]);

            Console.WriteLine(tp1);

            //read the second input and print the tuple;
            var inputLine2 = Console.ReadLine()
                .Split(' ');

            Tuple<string, int> tp2 = new Tuple<string, int>(inputLine2[0], int.Parse(inputLine2[1]));

            Console.WriteLine(tp2);

            //read the third input and print the tuple;
            var inputLine3 = Console.ReadLine()
                .Split(' ');

            Tuple<int, double> tp3 = new Tuple<int, double>(int.Parse(inputLine3[0]), double.Parse(inputLine3[1]));

            Console.WriteLine(tp3);
        }
    }
}
