﻿using System;

public interface IBirthable
{
    string Birthdate { get; }
}

