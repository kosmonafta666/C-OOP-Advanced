﻿namespace Card_Power
{
    using Card_Power.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class CardPower
    {
        public static void Main(string[] args)
        {
            PrintDeck();
        }

        //method to read card;
        public static Card ReadCard()
        {
            //read the rank of card;
            var rank = Console.ReadLine();
            //read the suit of card;
            var suit = Console.ReadLine();

            //create card;
            var card = new Card(rank, suit);

            return card;
        }

        public static void PrintAttributes()
        {
            var input = Console.ReadLine();

            if (input == "Rank")
            {
                PrintAttributes(typeof(Rank));
            }
            else
            {
                PrintAttributes(typeof(Suit));
            }
        }

        public static void PrintAttributes(Type type)
        {
            var attributes = type.GetCustomAttributes(false);

            Console.WriteLine(attributes[0]);
        }

        //method that prints all cards;
        public static void PrintDeck()
        {
            var deck = GenerateDeck();

            foreach (var card in deck)
            {
                Console.WriteLine(card.Name);
            }
        }

        //method that generates all cards;
        public static List<Card> GenerateDeck()
        {
            var deck = new List<Card>();

            foreach (var suit in Enum.GetNames(typeof(Suit)))
            {
                foreach (var rank in Enum.GetNames(typeof(Rank)))
                {
                    deck.Add(new Card(rank, suit));
                }
            }

            return deck;
        }

    }
}
