﻿namespace Card_Power
{
    using Card_Power.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class CardPower
    {
        public static void Main(string[] args)
        {
            //read the rank of card;
            var rank = Console.ReadLine();
            //read the suit of card;
            var suit = Console.ReadLine();

            //create card;
            var card = new Card(rank, suit);

            //print the result;
            Console.WriteLine(card);
        }
    }
}
