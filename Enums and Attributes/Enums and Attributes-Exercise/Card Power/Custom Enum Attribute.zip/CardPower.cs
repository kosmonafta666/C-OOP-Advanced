﻿namespace Card_Power
{
    using Card_Power.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class CardPower
    {
        public static void Main(string[] args)
        {
            PrintAttributes();
        }

        //method to read card;
        public static Card ReadCard()
        {
            //read the rank of card;
            var rank = Console.ReadLine();
            //read the suit of card;
            var suit = Console.ReadLine();

            //create card;
            var card = new Card(rank, suit);

            return card;
        }

        public static void PrintAttributes()
        {
            var input = Console.ReadLine();

            if (input == "Rank")
            {
                PrintAttributes(typeof(Rank));
            }
            else
            {
                PrintAttributes(typeof(Suit));
            }
        }

        public static void PrintAttributes(Type type)
        {
            var attributes = type.GetCustomAttributes(false);

            Console.WriteLine(attributes[0]);
        }
    }
}
